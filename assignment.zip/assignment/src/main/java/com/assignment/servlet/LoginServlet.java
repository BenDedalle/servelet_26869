package com.assignment.servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Assignment 1: Login Servlet
 * 
 * Handles user login with password validation:
 * - If password length < 8: displays "Hello <username>, your password is weak. Try a strong one."
 * - Otherwise: displays "Welcome <username>"
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Set response content type
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        try {
            // Get username and password parameters
            String username = request.getParameter("username");
            String password = request.getParameter("password");
            
            // Validate inputs
            if (username == null || username.trim().isEmpty() ||
                password == null || password.trim().isEmpty()) {
                
                out.println("<div style='color: #f59e0b; font-weight: 600;'>");
                out.println("Please provide both username and password.");
                out.println("</div>");
                return;
            }
            
            // Trim whitespace
            username = username.trim();
            password = password.trim();
            
            // Check password strength (length >= 8)
            if (password.length() < 8) {
                // Weak password response
                out.println("<div style='color: #f59e0b; font-weight: 600; font-size: 16px;'>");
                out.println("Hello <strong>" + escapeHtml(username) + "</strong>, your password is weak. Try a strong one.");
                out.println("</div>");
            } else {
                // Strong password - login successful
                out.println("<div style='color: #10b981; font-weight: 600; font-size: 16px;'>");
                out.println("Welcome <strong>" + escapeHtml(username) + "</strong>!");
                out.println("</div>");
                
                // Store user in session
                HttpSession session = request.getSession(true);
                session.setAttribute("username", username);
                session.setAttribute("loginTime", System.currentTimeMillis());
            }
            
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.println("<div style='color: #ef4444; font-weight: 600;'>");
            out.println("An error occurred: " + escapeHtml(e.getMessage()));
            out.println("</div>");
            e.printStackTrace();
        } finally {
            out.close();
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        out.println("<div style='color: #ef4444; font-weight: 600;'>");
        out.println("GET method is not supported. Please use POST.");
        out.println("</div>");
        out.close();
    }

    /**
     * Escape HTML special characters to prevent XSS attacks
     */
    private String escapeHtml(String text) {
        if (text == null) return "";
        return text
                .replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&#39;");
    }
}
