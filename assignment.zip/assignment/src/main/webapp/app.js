// Store logged-in user
let currentUser = null;

// Toggle between login and search forms
function toggleForm(sectionId) {
    const sections = document.querySelectorAll('.form-section');
    sections.forEach(section => {
        section.classList.remove('active');
    });
    document.getElementById(sectionId).classList.add('active');
}

// Display response message
function showMessage(message, type = 'info', isHtml = false) {
    const modal = document.getElementById('responseModal');
    const responseDiv = document.getElementById('responseMessage');
    
    if (isHtml) {
        responseDiv.innerHTML = message;
    } else {
        responseDiv.textContent = message;
    }
    
    // Set styling based on type
    responseDiv.className = `message-${type}`;
    modal.style.display = 'flex';
    
    // Auto-close after 5 seconds for success messages
    if (type === 'success') {
        setTimeout(() => {
            closeModal();
        }, 5000);
    }
}

// Close modal
function closeModal() {
    document.getElementById('responseModal').style.display = 'none';
}

// Close modal when clicking outside
window.addEventListener('click', (event) => {
    const modal = document.getElementById('responseModal');
    if (event.target === modal) {
        closeModal();
    }
});

// Handle search redirect (Assignment 2)
function handleSearch() {
    const searchQuery = document.getElementById('searchInput').value.trim();
    
    if (!searchQuery) {
        showMessage('Please enter a search query!', 'warning');
        return;
    }

    // Send to SearchServlet with redirect
    const form = document.createElement('form');
    form.method = 'POST';
    form.action = 'SearchServlet';
    
    const queryInput = document.createElement('input');
    queryInput.type = 'hidden';
    queryInput.name = 'query';
    queryInput.value = searchQuery;
    
    const userInput = document.createElement('input');
    userInput.type = 'hidden';
    userInput.name = 'user';
    userInput.value = currentUser || '';
    
    form.appendChild(queryInput);
    form.appendChild(userInput);
    document.body.appendChild(form);
    form.submit();
}

// Handle login form submission (Assignment 1)
document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('loginForm');
    
    if (loginForm) {
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const username = document.getElementById('username').value.trim();
            const password = document.getElementById('password').value.trim();
            
            if (!username || !password) {
                showMessage('Please fill in all fields!', 'warning');
                return;
            }
            
            // Create FormData for submission
            const formData = new FormData();
            formData.append('username', username);
            formData.append('password', password);
            
            try {
                const response = await fetch('LoginServlet', {
                    method: 'POST',
                    body: formData
                });
                
                const text = await response.text();
                
                // Parse response
                if (text.includes('weak')) {
                    showMessage(text, 'warning', true);
                } else if (text.includes('Welcome')) {
                    currentUser = username;
                    showMessage(text, 'success', true);
                    
                    // Show user greeting in search section
                    document.getElementById('greetingUsername').textContent = username;
                    document.getElementById('userGreeting').style.display = 'block';
                    
                    // Switch to search form after 2 seconds
                    setTimeout(() => {
                        toggleForm('searchSection');
                    }, 2000);
                } else {
                    showMessage('Login failed. Please try again.', 'warning', true);
                }
            } catch (error) {
                console.error('Error:', error);
                showMessage('An error occurred. Please try again.', 'warning');
            }
        });
    }

    // Add keyboard navigation
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            closeModal();
        }
    });
});

// Add enter key support for forms
document.addEventListener('DOMContentLoaded', () => {
    const inputs = document.querySelectorAll('input[type="text"], input[type="password"]');
    inputs.forEach(input => {
        input.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                const form = input.closest('form');
                if (form && form.id === 'loginForm') {
                    form.submit();
                }
            }
        });
    });
});
