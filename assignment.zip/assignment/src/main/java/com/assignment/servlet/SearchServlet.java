package com.assignment.servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLEncoder;

/**
 * Assignment 2: Search Redirect Servlet
 * 
 * Handles search functionality with redirect to Google:
 * - Receives search query from user input
 * - Redirects to Google search with the query
 * - Displays user greeting above the search
 */
@WebServlet("/SearchServlet")
public class SearchServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        try {
            // Get search query and username
            String query = request.getParameter("query");
            String username = request.getParameter("user");
            
            // Validate query
            if (query == null || query.trim().isEmpty()) {
                response.setContentType("text/html;charset=UTF-8");
                PrintWriter out = response.getWriter();
                out.println("<div style='color: #ef4444; font-weight: 600;'>");
                out.println("Please provide a search query.");
                out.println("</div>");
                out.close();
                return;
            }
            
            // Encode query for URL
            String encodedQuery = URLEncoder.encode(query.trim(), "UTF-8");
            
            // Build Google search URL
            String googleSearchUrl = "https://www.google.com/search?q=" + encodedQuery;
            
            // Perform redirect using sendRedirect
            response.sendRedirect(googleSearchUrl);
            
        } catch (Exception e) {
            response.setContentType("text/html;charset=UTF-8");
            PrintWriter out = response.getWriter();
            out.println("<div style='color: #ef4444; font-weight: 600;'>");
            out.println("An error occurred: " + escapeHtml(e.getMessage()));
            out.println("</div>");
            out.close();
            e.printStackTrace();
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        try {
            // Support GET method as well
            String query = request.getParameter("query");
            
            if (query == null || query.trim().isEmpty()) {
                response.setContentType("text/html;charset=UTF-8");
                PrintWriter out = response.getWriter();
                out.println("<div style='color: #ef4444; font-weight: 600;'>");
                out.println("Please provide a search query.");
                out.println("</div>");
                out.close();
                return;
            }
            
            // Encode query for URL
            String encodedQuery = URLEncoder.encode(query.trim(), "UTF-8");
            
            // Build Google search URL
            String googleSearchUrl = "https://www.google.com/search?q=" + encodedQuery;
            
            // Perform redirect using sendRedirect
            response.sendRedirect(googleSearchUrl);
            
        } catch (Exception e) {
            response.setContentType("text/html;charset=UTF-8");
            PrintWriter out = response.getWriter();
            out.println("<div style='color: #ef4444; font-weight: 600;'>");
            out.println("An error occurred: " + escapeHtml(e.getMessage()));
            out.println("</div>");
            out.close();
            e.printStackTrace();
        }
    }

    /**
     * Escape HTML special characters to prevent XSS attacks
     */
    private String escapeHtml(String text) {
        if (text == null) return "";
        return text
                .replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&#39;");
    }
}
